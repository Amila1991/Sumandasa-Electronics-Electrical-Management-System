
Sample Reports Fonts
=============================

Some of the supplied samples use the TrueType font files found in the 
/demo/fonts directory. In order to run those samples you should install 
these fonts into your operating system so that they are available to the JVM. 
The procedure required to install fonts depends on the operating system. 
On Windows systems this is equivalent to copying the font files into 
the <WINDOWS>\Fonts directory.
